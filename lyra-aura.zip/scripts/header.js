document.addEventListener('DOMContentLoaded', () => {
    fetch('../elements/header.html')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        return response.text();
    })
    .then(data => {
        document.querySelector('header').innerHTML = data;
    })
    .finally(() => {
        window.addEventListener('scroll', () => {
            window.scrollY > 30 || document.documentElement.scrollTop > 30 ? document.querySelector('header').classList.add('scrolled') : document.querySelector('header').classList.remove('scrolled');
        })

        const hamburger = document.querySelector('.hamburger');
        const hamburgerMenu = document.querySelector('.hamburger-menu');

        hamburger.addEventListener('click', (e) => {
            hamburgerMenu.classList.toggle('hidden');
            if (hamburgerMenu.classList.contains('hidden')) {
                hamburger.textContent = '/ Menu /';
            } else {
                hamburger.textContent = '/ Close /';
            }
        })
    })
    .catch(err => {
        console.error(err);
    });
})